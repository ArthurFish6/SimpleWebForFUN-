<?php
    header('Loaction: index.html');
    exit();
?>