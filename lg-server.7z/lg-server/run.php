<?php
  // On colle ce snippet dans notre fichier python.php
  $command = escapeshellcmd('ssh.pyw');
  $output = shell_exec($command);
  echo $output;
  header('Location: index.php');
  exit();
?>